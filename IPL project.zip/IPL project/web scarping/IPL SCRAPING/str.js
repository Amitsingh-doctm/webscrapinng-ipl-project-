let se= "sdf ";
se.trim();
 console.log(se);