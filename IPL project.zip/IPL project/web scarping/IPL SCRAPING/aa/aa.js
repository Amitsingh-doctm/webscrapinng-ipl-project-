
           let url1= "https://www.espncricinfo.com/series/ipl-2020-21-1210595/delhi-capitals-vs-mumbai-indians-final-1237181/full-scorecard";
            let request = require("request");
            let cheerio = require("cheerio");
           let fs= require("fs");
             let path= require("path");
            //const { syncBuiltinESMExports } = require("node:module");
            //const { strict } = require("node:assert");
            console.log("Before");
           request(url1, cb);
           function cb(error,response, html) {
               if (error) {
                   console.log(error)
               } else {
                   // console.log(html);
                   extractHtml14(html);
               }
           }
           let a1 = [];
           function extractHtml14(html) {
               let selTool12 = cheerio.load(html);
               let teamname= selTool12("p.name");
                // let a1=[];
                 for(let i=teamname.length-1;i>17;i--)
                 {
           
                    let z= selTool12(teamname[i]).text();
                  //  let f= z.split("INNINGS")
                      a1.push(z);
                     // let l=  a1.pop()
                      //console.log(l);
                   // console.log(f[0]);
                 }
                // f
                // for(int i=0;i<2;i++)
                // {
                    // a1.push(selTool(teamname[i]).text())
                // }
               let result= selTool12(".status-text span");
               console.log("amit");
                let finresult= selTool12(result[result.length-1]).text();
                //console.log(finresult);
           
                let batterstable = selTool12(".table.batsman");
               for (let i = 0; i < batterstable.length; i++) {
                   let ter2= a1[1-i];
                   let d= a1[i];
                   // let y=  a1[i];
                   //  let ter2= y[0];
                    // let ter2= e[0];
                     
           
                   let singleInningBol = selTool12(batterstable[i]).find("tbody tr");
                   for (let j = 0; j < singleInningBol.length; j++) {
                       let singleAllCol = selTool12(singleInningBol[j]).find("td");
                       let name = selTool12(singleAllCol[0]).text().trim();
                       
                       let r = selTool12(singleAllCol[2]).text();
                     let ball=  selTool12(singleAllCol[3]).text();
                     let four=  selTool12(singleAllCol[5]).text();
                    let sixes=   selTool12(singleAllCol[6]).text();
                    let sr  = selTool12(singleAllCol[7]).text();
                //  console.log(name+"-"+r+"-"+b+"-"+four+"-"+sixes+"-"+sr);
             let arr=[];
                
           
                 if(name!=="Extras" )
                  {
                   if(name[name.length-1]=="†" && name[name.length-2]==")")
                   {
                      let n = name.substr(0,name.length-5)
                      arr.push({
                       "team": ter2,
                         "oponant":d,
                        "player":n,
                        "run": r,
                         "for":four,
                         "six":sixes,
                         "runrate":sr,   
                      })
                      if(arr[0].player.length!==0)
                      {
                     //console.log(arr);
                     filcr(ter2,n,arr);
                         
                   }
                 }
                    else  if(name[name.length-1]=="†")
                    {
                    let n= name.substr(0,name.length-2)
                    arr.push({
                      "team": ter2,
                       "oponant":d,
                       "player":n,
                       "run": r,
                        "for":four,
                        "six":sixes,
                        "runrate":sr,   
                     })
                     if(arr[0].player.length!==0)
                     {
                    //console.log(arr);
                   filcr(ter2,n,arr);
                     }
                       //  console.log(n,r,four,sixes,sr);
                 }
               else if(name[name.length-1]==")")
                  {
                       let n= name.substr(0,name.length-4)
                       arr.push({
                         "team":ter2,
                             "opnonat":d,
                           "player":n,
                           "run": r,
                            "for":four,
                            "six":sixes,
                           "runrate":sr,
                         })
                         if(arr[0].player.length!=0)
                         {
                      // console.log(arr);
                         filcr(ter2,n,arr);
                         }
                     // console.log(m,r,four,sixes,sr);
                   }
                   else{
                       arr.push({
                           "team":ter2,
                           "oponent":d,
                            "player":name,
                            "run": r,
                            "for":four,
                            "six":sixes,
                            "runrate":sr,  
                         })
                         if(arr[0].player.length!=0)
                         {
                         console.log(arr);
                         filcr(ter2,name,arr);
                         }
                     //  console.log(name,r,four,sixes,s
                   }
               }
                // console.log(arr);
                   
                   
                  // console.log("```````");
                   // get all bowler name, wickets
               }
           }
           
            } //console.log(hwtname," : ",hwkt);
               // console.log(stringhtml);
               // compare wick
                function filcr(topicName,repoName,arr)
                {
                 let filePath = path.join(__dirname,topicName,repoName +".json");
                  fs.writeFileSync(filePath,JSON.stringify(arr));
                }
               