let url = "https://www.espncricinfo.com/series/ipl-2020-21-1210595/chennai-super-kings-vs-kings-xi-punjab-53rd-match-1216506/full-scorecard";
let request = require("request");
let cheerio = require("cheerio");
let fs= require("fs");
 let path= require("path");
//const { syncBuiltinESMExports } = require("node:module");
//const { strict } = require("node:assert");
console.log("Before");
request(url, cb);
function cb(error,response, html) {
    if (error) {
        console.log(error)
    } else {
        // console.log(html);
        extractHtml(html);
    }
}
  let a1 = [];
function extractHtml(html) {
    let selTool = cheerio.load(html);
    let teamname= selTool("p.name");
     // let a1=[];


      for(let i=teamname.length-1;i>17;i--)
      {

         let z= selTool(teamname[i]).text();
        // let f= z.split("INNINGS")
           a1.push(z);
          // let l=  a1.pop()
           //console.log(l);
        // console.log(f[0]);
      }
     // for(int i=0;i<2;i++)
     // {
         // a1.push(selTool(teamname[i]).text())
     // }
    let result= selTool(".status-text span");
    console.log("amit");
     let finresult= selTool(result[result.length-1]).text();
     //console.log(finresult);

     let batterstable = selTool(".table.batsman");
    for (let i = 0; i < batterstable.length; i++) {
        console.log(batterstable.length);
         let d= a1[1-i];
         let ter1=  a1[i];

         //let ter1= String(y);
         //let d= String(t);
         console.log(d);
         console.log(ter1);
        //  let ter1= ter[0];
          
          

        let singleInningBol = selTool(batterstable[i]).find("tbody tr");
        for (let j = 0; j < singleInningBol.length; j++) {
            let singleAllCol = selTool(singleInningBol[j]).find("td");
            let name = selTool(singleAllCol[0]).text().trim();
            
            let r = selTool(singleAllCol[2]).text();
          let ball=  selTool(singleAllCol[3]).text();
          let four=  selTool(singleAllCol[5]).text();
         let sixes=   selTool(singleAllCol[6]).text();
         let sr  = selTool(singleAllCol[7]).text();
     //  console.log(name+"-"+r+"-"+b+"-"+four+"-"+sixes+"-"+sr);
  let arr=[];
     

      if(name!=="Extras" )
       {
         if(name[name.length-1]=="†" && name[name.length-2]==")")
        {
           let n = name.substr(0,name.length-5)
           arr.push({
            "team": ter1,
              "oponant":d,
             "player":n,
             "run": r,
              "for":four,
              "six":sixes,
              "runrate":sr,   
           })
           if(arr[0].player.length!==0)
           {
           console.log(arr);

        }
      }
          else if(name[name.length-1]=="†")
         {
         let n= name.substr(0,name.length-2)
         arr.push({
           "team": ter1,
             "oponant":d,
            "player":n,
            "run": r,
             "for":four,
             "six":sixes,
             "runrate":sr,   
          })
          if(arr[0].player.length!==0)
          {
          //console.log(arr);
        //filcr(ter1,name,arr);
          }
            //  console.log(n,r,four,sixes,sr);
      }
         
    else if(name[name.length-1]==")")
       {
            let m= name.substr(0,name.length-4)
            arr.push({
              "team":ter1,
                  "opnonat":d,
                "player":m,
                "run": r,
                 "for":four,
                 "six":sixes,
                "runrate":sr,
              })
              if(arr[0].player.length!=0)
              {
              console.log(arr);
             // filcr(ter1,name,arr);
              }
          // console.log(m,r,four,sixes,sr);
        }
        else{
            arr.push({
                "team":ter1,
                "oponent":d,
                 "player":name,
                 "run": r,
                 "for":four,
                 "six":sixes,
                 "runrate":sr,  
              })
              if(arr[0].player.length!=0)
              {
              console.log(arr);
            //  filcr(ter1,name,arr);
              }
          //  console.log(name,r,four,sixes,s
        }
    }
     // console.log(arr);
        
        
       // console.log("```````````````````````````````");
        // get all bowler name, wickets
    }
}

 } //console.log(hwtname," : ",hwkt);
    // console.log(stringhtml);
    // compare wick
     function filcr(topicName,repoName,arr)
     {
      let filePath = path.join(__dirname, topicName,repoName + ".json");
       fs.writeFileSync(filePath, JSON.stringify(arr));
     }






