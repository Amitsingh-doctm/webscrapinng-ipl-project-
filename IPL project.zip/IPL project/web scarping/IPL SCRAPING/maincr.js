
let url = "https://www.espncricinfo.com/series/ipl-2020-21-1210595/match-results";
let request = require("request");
let cheerio = require("cheerio");
let fs= require("fs");
 let path= require("path");
console.log("Before");
request(url, cb);
function cb(error, response, html) {
    if (error) {
        console.log(error)
    } else {
        // console.log(html);
        extractHtml(html);
    }
}
function extractHtml(html) {
    let selTool = cheerio.load(html);
     let s=  selTool("a[data-hover='Squads']").attr("href");
     let v= selTool("a[data-hover='Scorecard']");
     //console.log(s);
    // teemfile(s);
       
        for(let i=0;i<v.length;i++)
        {
      //  console.log("https://www.espncricinfo.com/"+c);
      let m =selTool(v[i]).attr("href")

      let n= "https://www.espncricinfo.com/"+m;
     // console.log(n)
    
        }
     //console.log(v.length);
}

